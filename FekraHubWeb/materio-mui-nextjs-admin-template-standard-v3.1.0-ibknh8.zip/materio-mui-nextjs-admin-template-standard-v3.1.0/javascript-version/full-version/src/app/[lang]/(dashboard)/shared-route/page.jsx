const SharedRoutePage = () => {
  return <div>This page can be accessed via both LoggedIn and Not LoggedIn Users.</div>
}

export default SharedRoutePage
